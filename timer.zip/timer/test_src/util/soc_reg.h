
#ifndef __SOC_REGS_H__
#define __SOC_REGS_H__

#define CTRL_BASE 0x200000
#define CTRL_OUT  0x4
#define CTRL_CTRL 0x8

#endif  // __SOC_REGS_H__
